

class Ui:
    def __init__(self, service):
        self._service = service

    def _print_menu(self):
        print("Menu")
        print("1. Generate random graph")
        print("2. Read from file")
        print("3. Write to file")
        print("4. Print graph")
        print("5. Add vertex")
        print("6. Remove vertex")
        print("7. Add edge")
        print("8. Remove edge")
        print("9. Outbound vertices")
        print("10. Inbound vertices")
        print("11. Parse vertices")
        print("12. Modify information")
        print('13. Vertex number')
        print('14. Edge number')
        print('15. Copy graph')
        print('16. Print graph as tree')
        print('17. Change to copy')
        print("0. Exit")

    def _random_ui(self):
        n = input("\nEnter the number of vertices: ")
        m = input("Enter the number of edges: ")

        self._service.generate_random(n, m)

    def _read_from_file(self):
        file_name = input("\nEnter the file name: ")

        self._service.read_from_file(file_name)

    def _write_to_file(self):
        file_name = input("\nEnter the file name: ")

        self._service.write_to_file(file_name)

    def _print_graph(self):
        print(self._service.readable_graph())

    def _add_vertex_ui(self):
        x = input("\nEnter the vertex number: ")

        self._service.add_vertex(x)

    def _remove_vertex_ui(self):
        x = input("\nEnter the vertex number: ")

        self._service.remove_vertex(x)

    def _add_edge_ui(self):
        x = input("\nEnter the source vertex: ")
        y = input("Enter the destination vertex: ")
        val = input("Enter the information on the edge: ")

        self._service.add_edge(x, y, val)

    def _remove_edge_ui(self):
        x = input("\nEnter the source vertex: ")
        y = input("Enter the destination vertex: ")

        self._service.remove_edge(x, y)

    def _outbound(self):
        x = input("\nEnter the source vertex: ")

        string = str(x) + ': '
        for y in self._service.parse_out(x):
            string += str(y) + ' '
        print(string)

    def _inbound(self):
        x = input("\nEnter the destination vertex: ")

        string = str(x) + ': '
        for y in self._service.parse_in(x):
            string += str(y) + ' '
        print(string)

    def _print_vertices(self):
        string = ''
        for x in self._service.parse_all():
            string += str(x) + ' '
        print(string)

    def _modify(self):
        x = input("\nEnter the source vertex: ")
        y = input("Enter the destination vertex: ")
        val = input("Enter the information on the edge: ")

        self._service.modify_info(x, y, val)

    def _vertex_number(self):
        print(self._service.vertices_number())

    def _edge_number(self):
        print(self._service.edges_number())

    def _copy(self):
        self._service.copy_graph()

    def _print_tree(self):
        print(self._service.get_graph())

    def _change_copy(self):
        self._service.change_to_copy()

    def start(self):
        is_running = True

        command_dict = {'1': self._random_ui, '2': self._read_from_file, '3': self._write_to_file,
                        '4': self._print_graph, '5': self._add_vertex_ui, '6': self._remove_vertex_ui,
                        '7': self._add_edge_ui, '8': self._remove_edge_ui, '9': self._outbound,
                        '10': self._inbound, '11': self._print_vertices, '12': self._modify, '13': self._vertex_number,
                        '14': self._edge_number, '15': self._copy, '16': self._print_tree, '17': self._change_copy}

        while is_running:
            self._print_menu()

            command = input(">> ")
            try:
                if command in command_dict:
                    command_dict[command]()
                elif command == '0':
                    is_running = False
                else:
                    print("\nInvalid command\n")
            except Exception as ex:
                print(str(ex))
