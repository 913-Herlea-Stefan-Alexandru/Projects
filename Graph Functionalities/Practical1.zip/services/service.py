from domain.graph import Graph
import random


class Service:
    def __init__(self):
        """
        Creates an empty graph and an empty copy variable
        """
        self._graph = Graph()
        self._copy_g = None

    def vertices_number(self):
        """
        :return: the number of vertices in the current graph
        """
        return self._graph.get_vertex_count()

    def edges_number(self):
        """
        :return: the number of edges in the current graph
        """
        return self._graph.get_edge_count()

    def parse_out(self, x):
        """
        :param x: the given vertex (str)
        :return: the outbound neighbours of the given vertex x (list of int)
        """
        x = int(x)
        return self._graph.parseNOut(x)

    def parse_in(self, x):
        """
        :param x: the given vertex (str)
        :return: the outbound neighbours of the given vertex x (list of int)
        """
        x = int(x)
        return self._graph.parseNIn(x)

    def parse_all(self):
        """
        :return: a list of all the vertexes in the graph (list of int)
        """
        return self._graph.parseX()

    def add_edge(self, x, y, val):
        """
        Adds an edge to the graph
        :param x: source vertex (str)
        :param y: destination vertex (str)
        :param val: cost/info of the edge (str)
        :return:
        :raises ValueError: if the edge already exists
        """
        x = int(x)
        y = int(y)
        val = int(val)
        if not self._graph.add_edge(x, y, val):
            raise ValueError("\nEdge already created\n")

    def remove_edge(self, x, y):
        """
        Removes an edge from the graph
        :param x: source vertex (str)
        :param y: destination vertex (str)
        :return:
        :raises ValueError: if the edge does not exist
        """
        x = int(x)
        y = int(y)
        if not self._graph.remove_edge(x, y):
            raise ValueError("\nEdge not found\n")

    def add_vertex(self, x):
        """
        Adds a vertex to the graph
        :param x: the vertex (str)
        :return:
        :raises ValueError: if the vertex is already in the graph
        """
        x = int(x)
        if not self._graph.add_vertex(x):
            raise ValueError("\nVertex already exists\n")

    def remove_vertex(self, x):
        """
        Removes a vertex from the graph
        :param x: the vertex (str)
        :return:
        :raises ValueError: if the vertex is not in the graph
        """
        x = int(x)
        if not self._graph.remove_vertex(x):
            raise ValueError("\nVertex not found\n")

    def modify_info(self, x, y, new_val):
        """
        Modifies the cost/information of a given edge
        :param x: source vertex (str)
        :param y: destination vertex (str)
        :param new_val: new cost/info of the edge (str)
        :return:
        :raises ValueError: if the edge does not exist
        """
        x = int(x)
        y = int(y)
        new_val = int(new_val)

        if not self._graph.set_edge(x, y, new_val):
            raise ValueError("\nEdge does not exist\n")

    def delete_graph(self):
        """
        Deletes the current graph
        :return:
        """
        for x in self._graph.parseX():
            self._graph.remove_vertex(x)

    def copy_graph(self):
        """
        Copies the current graph into the copy variable
        :return:
        """
        self._copy_g = self._graph.copy_graph()

    def read_from_file(self, file_name):
        """
        Reads a graph from a file
        :param file_name: (str)
        :return:
        :raises ValueError: if the number of edges given is too high
        """
        f = open(file_name, "r")

        self.delete_graph()

        for line in f:
            tokens = line.split(" ")

            if len(tokens) == 2:
                n = int(tokens[0])
                m = int(tokens[1])
                if m > n * n:
                    raise ValueError("\nToo many edges\n")
                for x in range(n):
                    self._graph.add_vertex(x)
                continue
            if len(tokens) == 1:
                x = int(tokens[0])
                if not self._graph.check_vertex(x):
                    self._graph.add_vertex(x)
                continue

            x = int(tokens[0])
            y = int(tokens[1])
            val = int(tokens[2])

            if not self._graph.check_vertex(x):
                self._graph.add_vertex(x)
            if not self._graph.check_vertex(y):
                self._graph.add_vertex(y)
            self._graph.add_edge(x, y, val)

        f.close()

    def write_to_file(self, file_name):
        """
        Writes the current graph into a file
        :param file_name: (str)
        :return:
        """
        f = open(file_name, "w")
        f.write(str(self._graph))
        f.close()

    def generate_random(self, n, m):
        """
        Generates a random graph with the given number of vertexes and edges
        :param n: the number of vertexes (str)
        :param m: the number of edges (str)
        :return:
        :raises ValueError: if the number of edges is too high
        """
        self.delete_graph()
        n = int(n)
        m = int(m)

        if m > n * n:
            raise ValueError("\nToo many edges\n")

        for x in range(n):
            self._graph.add_vertex(x)
        while m > 0:
            x = random.choice(self._graph.parseX())
            y = random.choice(self._graph.parseX())

            if self._graph.check_edge(x, y):
                continue

            val = random.randint(1, 1000)
            self._graph.add_edge(x, y, val)
            m -= 1

    def change_to_copy(self):
        """
        Sets the copy as the current graph
        :return:
        :raises ValueError: if the copy is empty
        """
        if self._copy_g != None:
            self._graph, self._copy_g = self._copy_g, self._graph
        else:
            raise ValueError("\nThe copy is empty\n")

    def readable_graph(self):
        """
        :return: a readable format of the current graph (str)
        """
        return str(self._graph)

    def get_graph(self):
        """
        :return: a readable tree version of the current graph (str)
        """
        return self._graph.print_graph()
